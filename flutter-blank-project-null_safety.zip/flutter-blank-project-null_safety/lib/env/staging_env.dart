

import 'env.dart';

void main() => StagingEnv();

class StagingEnv extends Env {
  @override
  final String baseURL = '';
  @override
  final EnvironmentType type = EnvironmentType.staging;
  @override
  final String signature = '';
}
