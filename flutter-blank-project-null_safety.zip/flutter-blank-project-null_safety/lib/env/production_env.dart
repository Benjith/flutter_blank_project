
import 'env.dart';

void main() => ProductionEnv();

class ProductionEnv extends Env {
  @override
  final String baseURL = '';

  @override
  final EnvironmentType type = EnvironmentType.production;
  @override
  final String signature = '';
}
