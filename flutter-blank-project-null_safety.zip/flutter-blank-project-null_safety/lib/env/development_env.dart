


import 'env.dart';

class DevelopmentEnv extends Env {
  @override
  final String baseURL = '';
  @override
  final EnvironmentType type = EnvironmentType.development;
  @override
  final String signature = '';
}
