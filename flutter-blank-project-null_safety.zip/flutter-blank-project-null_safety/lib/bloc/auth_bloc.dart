import 'dart:async';

import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/model/country_model.dart';
import '../data/model/user_model.dart';
import '../data/repository/auth_repository.dart';
import '../routes/routes.dart';
import '../utils/app_constants.dart';
import 'core_bloc.dart';

class AuthBloc {
  AuthRepository repository = AuthRepository();

  Future<void> setUserToken(UserModel model) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();

    preferences.setString(AppConstants.TOKEN, model.auth!.accessToken!);
    AppConstants.loggedUser = model;
    preferences.setString(
        AppConstants.USERMODEL_STRING, userModelToJson(model));
  }

  void logout() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.remove(AppConstants.TOKEN);
    preferences.remove(AppConstants.USERMODEL_STRING);
    AppConstants.loggedUser = null;
    AppConstants.navigatorKey.currentState
        ?.pushNamedAndRemoveUntil(Routes.LOGIN_SCREEN, (route) => false);
  }

  Future<void> login(
      String email, String password, BuildContext context) async {
    try {
      UserModel response = await repository.login(email, password);

      await setUserToken(response);

      if (response.userData?.country != null) {
        await CoreBloc().updateDefaultCountry(CountryListModel(
            id: response.userData!.country?.id,
            dialCode: response.userData!.country?.dialCode,
            flagUrl: response.userData!.country?.flagUrl,
            name: response.userData?.country!.name));
      }
      Navigator.pushNamedAndRemoveUntil(
          context, Routes.DASHBOARD_SCREEN, (route) => false);
    } catch (e) {
      // AppConstants.showSnackOrange(context, e.toString());
    }
  }

  dispose() {}

  Future<bool> checkTokenExists() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    try {
      // return preferences.containsKey(AppConstants.TOKEN);
      if (preferences.containsKey(AppConstants.USERMODEL_STRING)) {
        AppConstants.loggedUser = userModelFromJson(
            preferences.getString(AppConstants.USERMODEL_STRING));
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }
}
