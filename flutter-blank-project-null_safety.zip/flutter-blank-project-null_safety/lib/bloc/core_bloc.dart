import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import '../../data/model/user_model.dart';
import '../../env/env.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info/device_info.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../service_locator.dart' as di;
import '../data/model/country_model.dart';
import '../data/repository/core_repository.dart';
import '../utils/app_constants.dart';
import 'language_bloc.dart';

class CoreBloc {
  CoreRepository repository = CoreRepository();

  Future<bool> initSharedData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    //settings default values
    if (!sharedPreferences.containsKey(AppConstants.UNREAD_MESSAGE_STRING)) {
      sharedPreferences.setBool(AppConstants.UNREAD_MESSAGE_STRING, false);
    } else {
      AppConstants.unreadMessage =
          sharedPreferences.getBool(AppConstants.UNREAD_MESSAGE_STRING)!;
    }
    if (!sharedPreferences.containsKey(AppConstants.COUNTRY_CODE)) {
      sharedPreferences.setString(AppConstants.COUNTRY_CODE, 'US');
    }
    if (!sharedPreferences.containsKey(AppConstants.LANGUAGE_CODE)) {
      sharedPreferences.setString(AppConstants.LANGUAGE_CODE, 'en');
    } else {
      di.sl<LanguageBloc>();
    }
    if (sharedPreferences.containsKey(AppConstants.DEFAULT_COUNTRY_STRING)) {
      AppConstants.defaultCountry = countryListModelFromJson(
          sharedPreferences.getString(AppConstants.DEFAULT_COUNTRY_STRING));
    } else {
      var initial =
          CountryListModel(dialCode: "+971", flagUrl: "", id: 231, name: 'UAE');

      updateDefaultCountry(initial);
    }
    if (sharedPreferences.containsKey(AppConstants.USERMODEL_STRING)) {
      AppConstants.loggedUser = userModelFromJson(
          sharedPreferences.getString(AppConstants.USERMODEL_STRING));
    }
    //get device info
    try {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      if (Platform.isAndroid) {
        AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
        AppConstants.userAgent = {
          'buildType': describeEnum(Env.instance.type!).toUpperCase(),
          'appName': packageInfo.appName,
          'deviceModel': androidInfo.model,
          'deviceOS': 'ANDROID',
          'deviceAPILevel': androidInfo.version.sdkInt,
          'versionCode': packageInfo.buildNumber,
          'versionName': packageInfo.version,
          'androidVersion': androidInfo.version.release,
        };
      }
      if (Platform.isIOS) {
        IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
        AppConstants.userAgent = {
          'buildType': describeEnum(Env.instance.type!).toUpperCase(),
          'appName': packageInfo.appName,
          'deviceModel': iosInfo.utsname.machine,
          'deviceOS': 'IOS',
          'versionCode': packageInfo.buildNumber,
          'iosVersion': iosInfo.systemVersion,
          'versionName': packageInfo.version
        };
      }
    } catch (e) {}
    return Future.value(true);
  }

  Future<bool> removeSharedData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    return sharedPreferences.clear();
  }

  Future enableUnread(bool value) async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    _prefs.setBool(AppConstants.UNREAD_MESSAGE_STRING, value);
    AppConstants.unreadMessage = value;
  }

  Future<void> updateDefaultCountry(CountryListModel data) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString(
        AppConstants.DEFAULT_COUNTRY_STRING, countryListModelToJson(data));
    AppConstants.defaultCountry = data;
  }

  dispose() {}
}
