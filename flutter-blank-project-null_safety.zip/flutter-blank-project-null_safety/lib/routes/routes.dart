import 'package:flutter/material.dart';

class Routes {
  static const String DASHBOARD_SCREEN = '/dashboard';
  static const String SPLASH_SCREEN = '/';
  static const String LOGIN_SCREEN = '/login';

  static const String REGISTER_SCREEN = '/register';
}
