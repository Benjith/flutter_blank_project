import 'package:flutter/material.dart';

class ColorResources {
  static const Color COLOR_GREY = Color(0xFFA0A4A8);
  static const Color COLOR_GREY01 = Color(0xFFECEFF3);
  static const Color COLOR_GREY03 = Color(0xFF26565272);
  static const Color COLOR_BLACK = Color(0xFF000000);
  static const Color COLOR_BLACK02 = Color(0xFF23293b);
  static const Color COLOR_BLACK03 = Color(0xFF13224a);


  static Color hexToColor(String code) {
    
    return new Color(int.parse(code.substring(1, 7), radix: 16) + 0xFF000000);
  }

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.isEmpty) {
      return Color(0xFF252525);
    } else {
      if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
      buffer.write(hexString.replaceFirst('#', ''));
      return Color(int.parse(buffer.toString(), radix: 16));
    }
  }
}
