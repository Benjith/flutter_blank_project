import 'package:flutter/material.dart';

import 'app_constants.dart';

import 'dimensions.dart';

const font12spW400 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL,
  fontWeight: FontWeight.w400,
);
const font13spW400 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL2,
  fontWeight: FontWeight.w400,
);
const font14spW400 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w400,
);
const font13spW500 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL2,
  fontWeight: FontWeight.w500,
);
const font12spW500 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL,
  fontWeight: FontWeight.w500,
);
const font12spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL,
  fontWeight: FontWeight.w600,
);
const font14spW500 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w500,
);
const font14spW300 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_DEFAULT,
  fontWeight: FontWeight.w300,
);
const font17spW500 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_LARGE2,
  fontWeight: FontWeight.w500,
);
const font17spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_LARGE2,
  fontWeight: FontWeight.w600,
);
const font12spW300 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_SMALL,
  fontWeight: FontWeight.w300,
);
const font20spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_20,
  fontWeight: FontWeight.w600,
);
const font16spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_LARGE,
  fontWeight: FontWeight.w600,
);
const font18spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_EXTRA_LARGE,
  fontWeight: FontWeight.w600,
);
const font24spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: Dimensions.FONT_SIZE_24,
  fontWeight: FontWeight.w600,
);
const font19spW600 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: 19,
  fontWeight: FontWeight.w600,
);
const font15spW500 = TextStyle(
  fontFamily: AppConstants.fontFamilyName,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);

const EdgeInsets pagePadding =
    EdgeInsets.symmetric(horizontal: Dimensions.SCREEN_CONTAINER_SIZE);
const EdgeInsets pagePaddingXL =
    EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_XL);
const EdgeInsets pagePaddingXXL =
    EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_XXL);
