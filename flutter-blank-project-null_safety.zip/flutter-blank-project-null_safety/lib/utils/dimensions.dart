class Dimensions {
  static const double FONT_SIZE_EXTRA_SMALL = 10.0;
  static const double FONT_SIZE_SMALL = 12.0;
  static const double FONT_SIZE_SMALL2 = 13.0;
  static const double FONT_SIZE_DEFAULT = 14.0;
  static const double FONT_SIZE_LARGE = 16.0;
  static const double FONT_SIZE_LARGE2 = 17.0;
  static const double FONT_SIZE_EXTRA_LARGE = 18.0;
  static const double FONT_SIZE_20 = 20.0;
  static const double FONT_SIZE_24 = 24.0;
  static const double FONT_SIZE_19 = 24.0;

  static const double PADDING_SIZE_XS = 5.0;
  static const double PADDING_SIZE_S = 10.0;
  static const double PADDING_SIZE_DEFAULT = 15.0;
  static const double PADDING_SIZE_L1 = 20.0;
  static const double PADDING_SIZE_L2 = 23.0;
  static const double PADDING_SIZE_XL = 26.0;
  static const double PADDING_SIZE_XXL = 50;
  static const double PADDING_SIZE_40 = 44;

  static const double SCREEN_CONTAINER_SIZE = 24.5;
}
