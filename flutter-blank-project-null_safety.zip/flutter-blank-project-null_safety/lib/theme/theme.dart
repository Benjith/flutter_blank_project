import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

ThemeData lightThemeData = ThemeData(
    fontFamily: 'Poppins',
    primaryColor: Color(0xFFef612b),
    brightness: Brightness.light,
    scaffoldBackgroundColor: Colors.white,
    accentColor: Color(0xFF2C2C2C),
    hintColor: Color(0xFFE7F6F8),
    focusColor: Color(0xFFADC4C8),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
        selectedIconTheme: IconThemeData(color: Colors.red)),
    textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
      primary: Colors.white,
      textStyle: TextStyle(color: Colors.white),
    )),
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
      TargetPlatform.iOS: ZoomPageTransitionsBuilder(),
      TargetPlatform.fuchsia: ZoomPageTransitionsBuilder(),
    }),
    textTheme: GoogleFonts.poppinsTextTheme());
