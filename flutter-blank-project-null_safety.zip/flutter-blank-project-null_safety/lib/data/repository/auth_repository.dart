import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/app_constants.dart';
import '../model/user_model.dart';
import '../remote/dio/dio_client.dart';
import '../remote/dio/dio_interceptor.dart';
import '../remote/dio/exceptions.dart';

class AuthRepository {
  final DioClient dioClient =
      DioClient(loggingInterceptor: LoggingInterceptor());

  Future<UserModel> login(String email, String password) async {
    try {
      final response = await dioClient.post(AppConstants.LOGIN_URI,
          data: {"username": email, "password": password});
      return UserModel.fromJson(response.data['response']);
    } catch (e) {
      throw ApiException(e);
    }
  }
}
