import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../main.dart';
import '../service_locator.dart' as di;
import 'package:firebase_analytics/firebase_analytics.dart';

import '../bloc/core_bloc.dart';
import 'development_env.dart';
import 'production_env.dart';
import 'staging_env.dart';

class Env {
  static Env instance;
  String baseURL;
  EnvironmentType type;
  String signature;

  Env() {
    main();
  }

  void main() async {
    instance = this;
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    LicenseRegistry.addLicense(() async* {
      final license =
          await rootBundle.loadString('assets/fonts/poppins/OFL.txt');
      yield LicenseEntryWithLineBreaks(['google_fonts'], license);
    });
    FirebaseAnalytics analytics = FirebaseAnalytics.instance;
    FirebaseAnalyticsObserver observer =
        FirebaseAnalyticsObserver(analytics: analytics);
    await di.init();
    analytics.logAppOpen();

    // await analytics.logEvent(
    //   name: 'test_event',
    //   parameters: <String, dynamic>{
    //     'string': 'string',
    //     'int': 42,
    //     'long': 12345678910,
    //     'double': 42.0,
    //     'bool': true.toString(),
    //   },
    // );
    await CoreBloc().initSharedData();
    runZonedGuarded(() {
      runApp(MyApp(this));
    }, FirebaseCrashlytics.instance.recordError);
  }
}

enum EnvironmentType {
  development,
  staging,
  production,
}

getEnvironment() {
  // 0 - Development, 1 - Staging, 2 - Production
  // fetch environment value in const variable only.
  // set configuration --dart-define=ENVIRONMENT_TYPE=1
  // default production environment will be loaded.
  const environment = int.fromEnvironment('ENVIRONMENT_TYPE',
      defaultValue: 0); // defaultValue : Production
  switch (EnvironmentType.values[environment]) {
    case EnvironmentType.development:
      return DevelopmentEnv();
      break;
    case EnvironmentType.staging:
      return StagingEnv();
      break;
    case EnvironmentType.production:
      return ProductionEnv();
      break;
    default:
      return ProductionEnv();
  }
}

const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'Notifications', // title
  'For notifications.', // description
  importance: Importance.high,
);
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {

  await CoreBloc().enableUnread(true);
}
