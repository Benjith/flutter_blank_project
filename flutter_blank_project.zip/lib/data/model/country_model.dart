// To parse this JSON data, do
//
//     final countryListModel = countryListModelFromJson(jsonString);

import 'dart:convert';

CountryListModel countryListModelFromJson(String str) =>
    CountryListModel.fromJson(json.decode(str));

String countryListModelToJson(CountryListModel data) =>
    json.encode(data.toJson());

class CountryListModel {
  CountryListModel({this.id, this.name, this.flagUrl, this.dialCode});

  int id;
  String name;
  String dialCode;
  String flagUrl;

  factory CountryListModel.fromJson(Map<String, dynamic> json) =>
      CountryListModel(
        id: json["id"] == null ? null : json["id"],
        name: json["nameEn"] == null ? null : json["nameEn"],
        dialCode: json["dialCode"] == null ? null : json["dialCode"],
        flagUrl: json["flagUrl"] == null ? null : json["flagUrl"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "nameEn": name == null ? null : name,
        "dialCode": dialCode == null ? null : dialCode,
        "flagUrl": flagUrl == null ? null : flagUrl,
      };
}
