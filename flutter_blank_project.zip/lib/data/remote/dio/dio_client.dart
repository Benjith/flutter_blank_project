import 'dart:io';

import 'package:dio/dio.dart';



import '../../../bloc/auth_bloc.dart';
import '../../../utils/app_constants.dart';
import 'dio_interceptor.dart';

class DioClient {
  final LoggingInterceptor loggingInterceptor;

  Dio dio = Dio();
  String token;
  String fcmToken;

  DioClient({
    this.loggingInterceptor,
  }) {
    dio
      ..options.baseUrl = AppConstants.apiVersionUrl
      ..options.connectTimeout = 30000
      ..options.receiveTimeout = 30000
      ..httpClientAdapter;

    dio.interceptors.add(loggingInterceptor);
    dio.interceptors.add(InterceptorsWrapper(
        onError: (DioError error, ErrorInterceptorHandler handler) async {
      if (error.response?.statusCode == 401 &&
          AppConstants.loggedUser?.auth != null) {
        // return AuthBloc().logout();

        dio.interceptors.requestLock.lock();
        dio.interceptors.responseLock.lock();
        RequestOptions options = error.response.requestOptions;
        Response _resp;
        try {
          _resp = await Dio().post(
            AppConstants.apiVersionUrl + AppConstants.TOKEN_REFRESH,
            data: {"refresh": AppConstants.loggedUser.auth.refreshToken},
            options: Options(
              headers: options.headers,
            ),
          );
        } on DioError catch (e) {
          dio.interceptors.requestLock.unlock();
          dio.interceptors.responseLock.unlock();
          handler.reject(error);
          return AuthBloc().logout();
        }
        switch (_resp.statusCode) {
          case 200:
            if (_resp.data["access"] != null) {
              AppConstants.loggedUser.auth.accessToken = _resp.data["access"];
              if (_resp.data["refreshToken"] != null) {
                AppConstants.loggedUser.auth.refreshToken =
                    _resp.data["refreshToken"];
              }
              AuthBloc().setUserToken(AppConstants.loggedUser);
              options.headers["Authorization"] =
                  "Bearer " + AppConstants.loggedUser.auth.accessToken;
            } else {
              dio.interceptors.requestLock.unlock();
              dio.interceptors.responseLock.unlock();
              handler.next(error);
              return AuthBloc().logout();
            }

            dio.interceptors.requestLock.unlock();
            dio.interceptors.responseLock.unlock();
            dio.unlock();
            try {
              var resp = await dio.request(
                AppConstants.apiVersionUrl + options.path,
                data: options.data,
                options: Options(
                  headers: options.headers,
                  method: options.method,
                ),
              );
              handler.resolve(resp);
            } catch (e) {
              handler.next(error);
              return AuthBloc().logout();
            }

            break;
          default:
            return handler.next(error);
            break;
        }
      } else {
        return handler.next(error);
      }
    }));
  }

  Future<Response> get(
    String uri, {
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
    ProgressCallback onReceiveProgress,
  }) async {
    try {
      var response = await dio.get(
        uri,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
        onReceiveProgress: onReceiveProgress,
      );
      return response;
    } on SocketException catch (e) {
      throw SocketException(e.toString());
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      throw e;
    }
  }

  Future<Response> post(
    String uri, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
    ProgressCallback onSendProgress,
    ProgressCallback onReceiveProgress,
  }) async {
    try {
      var response = await dio.post(
        uri,
        data: data,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress,
      );
      return response;
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      throw e;
    }
  }

  Future<Response> put(
    String uri, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
    ProgressCallback onSendProgress,
    ProgressCallback onReceiveProgress,
  }) async {
    try {
      var response = await dio.put(
        uri,
        data: data,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress,
      );
      return response;
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      throw e;
    }
  }

  Future<Response> delete(
    String uri, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
  }) async {
    try {
      var response = await dio.delete(
        uri,
        data: data,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
      );
      return response;
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      throw e;
    }
  }
}
