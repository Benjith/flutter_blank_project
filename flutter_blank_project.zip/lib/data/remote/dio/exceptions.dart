import 'package:dio/dio.dart';

import '../../../env/env.dart';


class ApiException implements Exception {
  final dynamic error;

  ApiException([this.error]);

  String toString() {
    if (error == null) return "Exception";
    if (error is Exception) {
      try {
        if (error is DioError) {
          switch (error.type) {
            case DioErrorType.cancel:
              return "Request to API server was cancelled";
              break;
            case DioErrorType.connectTimeout:
              return "Connection timeout with API server";
              break;
            case DioErrorType.other:
              return "Connection to API server failed due to internet connection";
              break;
            case DioErrorType.receiveTimeout:
              return "Receive timeout in connection with API server";
              break;
            case DioErrorType.response:
              switch (error.response.statusCode) {
                case 404:
                case 500:
                case 503:
                  return error.response.statusMessage;
                  break;
                default:
                  if (error?.response?.data['message'] != null)
                    return Env.instance.type == EnvironmentType.development
                        ? error.response.data['debugMessage'].toString()
                        : error.response.data['message'].toString();
                  else
                    return "Failed to load data - status code: ${error.response.statusCode}";
              }
              break;
            case DioErrorType.sendTimeout:
              return "Send timeout with server";
              break;
          }
        } else {
          return "Unexpected error occurred";
        }
      } on FormatException catch (e) {
        return e.toString();
      }
    } else {
      return "is not a subtype of exception";
    }
    return error.toString();
  }
}
