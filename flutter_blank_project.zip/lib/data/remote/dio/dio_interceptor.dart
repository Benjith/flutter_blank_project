import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:dio/dio.dart';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../helper/signature_generator.dart';
import '../../../service_locator.dart' as di;
import '../../../bloc/language_bloc.dart';
import '../../../utils/app_constants.dart';

class LoggingInterceptor extends InterceptorsWrapper {
  @override
  Future onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    DateTime _now = DateTime.now().toUtc();

    options.headers.addAll({
      'Timestamp': _now.millisecondsSinceEpoch,
      'Signature': HmacSignatureGenerator.generateHmacsignature(
          options.path, options.method, _now.millisecondsSinceEpoch),
      'Content-Type': 'application/json; charset=UTF-8',
      'Authorization': AppConstants.loggedUser?.auth == null
          ? ""
          : 'Bearer ${AppConstants.loggedUser.auth.accessToken}',
      'Access-Control-Allow-Origin': '*',
      'Device-Type': Platform.isAndroid
          ? 1
          : Platform.isIOS
              ? 2
              : 0,
      'Device-Token': AppConstants.fcmToken ?? "",
      'Language': di.sl<LanguageBloc>().locale.languageCode,
      'User-Agent': AppConstants.userAgent ?? {}
    });
    print("--> ${options.method} ${AppConstants.apiVersionUrl}${options.path}");
    log("Headers: ${options.headers.toString()}");
    log("Parms: ${options.data.toString()}");
    return super.onRequest(options, handler);
  }

  @override
  Future onResponse(
      Response response, ResponseInterceptorHandler handler) async {
    log(jsonEncode(response.data).toString());
    // print("<-- END HTTP");
    // print(response.data.toString());
    return response.data['hasError']
        ? handler.reject(DioError(
            requestOptions: response.requestOptions,
            error: response.data,
            response: response,
            type: DioErrorType.response))
        : super.onResponse(response, handler);
  }

  @override
  Future onError(DioError error, ErrorInterceptorHandler handler) async {
    print(
        "ERROR[${error?.response?.statusCode}] => PATH: ${error?.requestOptions?.path}");
    log(error?.response?.data.toString());

    return super.onError(error, handler);
  }
}
