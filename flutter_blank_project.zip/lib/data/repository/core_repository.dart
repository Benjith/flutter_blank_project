import '../remote/dio/dio_interceptor.dart';

import '../remote/dio/dio_client.dart';

class CoreRepository {
  final DioClient dioClient =
      DioClient(loggingInterceptor: LoggingInterceptor());
}
