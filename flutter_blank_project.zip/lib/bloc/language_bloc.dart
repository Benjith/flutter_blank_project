import 'package:flutter/material.dart';


import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_constants.dart';

class LanguageBloc {
  LanguageBloc() {
    _loadCurrentLanguage();
  }

  Locale _locale = Locale('en', 'US');
  bool _isLtr = true;
  Locale get locale => _locale;
  bool get isLtr => _isLtr;

  void setLanguage(Locale locale) {
    _locale = locale;

    _saveLanguage(_locale);
  }

  _loadCurrentLanguage() async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    _locale = Locale(
        sharedPreferences.getString(AppConstants.LANGUAGE_CODE) ?? 'en',
        sharedPreferences.getString(AppConstants.COUNTRY_CODE) ?? 'US');
    _isLtr = _locale.languageCode == 'en';
    // notifyListeners();
  }

  _saveLanguage(Locale locale) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    sharedPreferences.setString(
        AppConstants.LANGUAGE_CODE, locale.languageCode);
    sharedPreferences.setString(AppConstants.COUNTRY_CODE, locale.countryCode);
  }
}
