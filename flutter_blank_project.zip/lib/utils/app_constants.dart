import 'package:flutter/material.dart';
import 'package:search4job/data/model/language_model.dart';

import '../data/model/country_model.dart';
import '../data/model/user_model.dart';
import '../env/env.dart';
import 'asset_resources.dart';
import 'colour_resources.dart';
import 'style.dart';

class AppConstants {
  // app constants
  static const String APP_NAME = '';
  static const String COMPANY_NAME = '';

  // URLS
  static String baseURL = Env.instance.baseURL;
  static String apiVersionUrl = baseURL + '/api/';
  static const String TOKEN_REFRESH = 'token/refresh';
  static String LOGIN_URI = apiVersionUrl + 'token/refresh';

  // Shared Key
  static const String THEME = 'theme';
  static const String TOKEN = 'token';
  static const String FCM = 'fcm';
  static const String COUNTRY_CODE = 'countryCode';
  static const String LANGUAGE_CODE = 'languageCode';
  static const String DEFAULT_COUNTRY_STRING = 'defaultCountry';
  static const String USERMODEL_STRING = 'usermodel';
  static const String UNREAD_MESSAGE_STRING = 'unreadMessage';

  // naviagator key
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static const String fontFamilyName = 'Poppins';

  static String fcmToken = '';

  static List<LanguageModel> languages = [
    LanguageModel(
        imageUrl: Assets.icon('ic_eng.png'),
        languageName: 'English',
        countryCode: 'US',
        languageCode: 'en'),
    LanguageModel(
        imageUrl: Assets.image('uae.png'),
        languageName: 'Arabic',
        countryCode: 'SA',
        languageCode: 'ar'),
  ];

  static UserModel loggedUser;
  static Map userAgent;
  static CountryListModel defaultCountry;
  static bool unreadMessage = false;
}
