class Assets {


  static String image(String fileName) {
    return 'assets/image/$fileName';
  }
   static String icon(String fileName) {
    return 'assets/icon/$fileName';
  }


}
