class Strings {
  static const String lorem__ipsm__nonu =
      'Lorem ipsum dolor sit amet, consetetur the sadipscing elitr, sed diam nonu.';
  static const String LOGIN = 'login';
  static const String CANCEL = 'Cancel';
  
}
