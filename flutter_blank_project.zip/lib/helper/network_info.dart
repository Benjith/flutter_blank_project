import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import '../i18n/language_constants.dart';

import '../utils/app_constants.dart';

class NetworkInfo {
  final Connectivity connectivity;
  NetworkInfo(this.connectivity);

  Future<bool> get isConnected async {
    ConnectivityResult _result = await connectivity.checkConnectivity();
    return _result != ConnectivityResult.none;
  }

  static void checkConnectivity() {
    bool _firstTime = true;

    Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) async {
      bool isNotConnected = result != ConnectivityResult.wifi &&
          result != ConnectivityResult.mobile;

      if (!_firstTime) {
        isNotConnected
            ? SizedBox()
            : ScaffoldMessenger.of(AppConstants.navigatorKey.currentContext)
                .hideCurrentSnackBar();
        ScaffoldMessenger.of(AppConstants.navigatorKey.currentContext)
            .showSnackBar(SnackBar(
          backgroundColor: isNotConnected ? Colors.red : Colors.green,
          duration: Duration(seconds: isNotConnected ? 3 : 3),
          content: Row(
            children: [
              Text(
                isNotConnected
                    ? getTranslated('no_connection',
                        AppConstants.navigatorKey.currentContext)
                    : getTranslated(
                        'connected', AppConstants.navigatorKey.currentContext),
                textAlign: TextAlign.start,
              ),
              SizedBox(
                width: 5,
              ),
              Icon(
                isNotConnected ? Icons.wifi_off : Icons.wifi,
                color: Colors.white,
              )
            ],
          ),
        ));
      }
      _firstTime = false;
    });
  }
}
