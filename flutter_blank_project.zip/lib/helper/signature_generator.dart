import 'dart:convert';


import 'package:crypto/crypto.dart';

import '../env/env.dart';
import '../utils/app_constants.dart';

class HmacSignatureGenerator {
  static String generateHmacsignature(
      String endPoint, String method, int timeStamp) {
    var formattedBaseString =
        '${AppConstants.baseURL}::API::$endPoint::$method::$timeStamp';

    var hmacSha1 = new Hmac(sha1, Env.instance.signature.codeUnits);

    final result = base64Encode(
        hmacSha1.convert(formattedBaseString.codeUnits).bytes.sublist(0, 16));

    String generatedSignature = result;
    if (generatedSignature.contains('+')) {
      generatedSignature = generatedSignature.replaceAll('+', '-');
    }
    if (generatedSignature.contains('/')) {
      generatedSignature = generatedSignature.replaceAll('/', '_');
    }

    return generatedSignature;
  }
}
