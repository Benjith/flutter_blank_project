import 'dart:async';
import 'dart:io';

import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'bloc/auth_bloc.dart';
import 'bloc/language_bloc.dart';
import 'env/env.dart';

import 'i18n/app_localization.dart';

import 'routes/routes.dart';
import 'theme/theme.dart';
import 'utils/app_constants.dart';
import 'utils/asset_resources.dart';
import 'utils/strings.dart';
import 'utils/style.dart';

import 'view/widgets/custom_widgets.dart';
import 'service_locator.dart' as di;
import 'helper/crashlytics.dart';

void main() async {
  getEnvironment();
}

class MyApp extends StatefulWidget {
  final Env env;

  final List<Locale> _locals = [];
  MyApp(this.env) {
    AppConstants.languages.forEach((language) {
      _locals.add(Locale(language.languageCode, language.countryCode));
    });
  }
  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>();

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = di.sl<LanguageBloc>().locale;
  Future<void> _initializeFlutterFireFuture;

  void setLocale(Locale value) {
    setState(() {
      _locale = value;
      di.sl<LanguageBloc>().setLanguage(value);
    });
  }

  @override
  void initState() {
    super.initState();
    _initializeFlutterFireFuture = initializeFlutterFire();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return MaterialApp(
      title: AppConstants.APP_NAME,
      theme: lightThemeData,
      themeMode: ThemeMode.light,
      initialRoute: Routes.SPLASH_SCREEN,
      navigatorKey: AppConstants.navigatorKey,
      debugShowCheckedModeBanner: false,
      localizationsDelegates: [
        AppLocalization.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      supportedLocales: widget._locals,
      locale: _locale,
      onUnknownRoute: (
        settings,
      ) {
        // inavlid page
        //  return MaterialPageRoute(builder: (context) => error page ());
      },
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case Routes.DASHBOARD_SCREEN:
            // return MaterialPageRoute(builder: (context) => DashboardScreen());
            break;

          default:
            return null;
        }
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  AuthBloc _authBloc = AuthBloc();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Future.delayed(Duration(seconds: 4), () async {
        if (await _authBloc.checkTokenExists()) {
          AppConstants.navigatorKey.currentState
              .pushReplacementNamed(Routes.DASHBOARD_SCREEN);
        } else {
          AppConstants.navigatorKey.currentState
              .pushReplacementNamed(Routes.LOGIN_SCREEN);
        }
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            child: Center(
              child: Hero(
                  tag: 'logo', child: Image.asset(Assets.image('logo.png'))),
            ),
            decoration: BoxDecoration(),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 50.0),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: CustomWidgets.stoppedAnimationProgress(),
            ),
          ),
        ],
      ),
    );
  }
}
