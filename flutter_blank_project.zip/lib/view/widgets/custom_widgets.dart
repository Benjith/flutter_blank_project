import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../utils/asset_resources.dart';
import '../../i18n/language_constants.dart';
import '../../utils/strings.dart';
import '../../utils/colour_resources.dart';

import 'dart:math' as math;

import '../../utils/style.dart';

class CustomWidgets {
  static Future<bool> showAlert(context, {content, actionTitle}) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Container(
          // height: 150,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(content ?? "",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      color: ColorResources.COLOR_GREY,
                      fontWeight: FontWeight.w400,
                      fontSize: 16.0)),
              SizedBox(height: 15),
              Divider(),
              SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      color: Colors.white,
                      width: 100,
                      alignment: Alignment.center,
                      child: Text(
                        getTranslated(Strings.CANCEL, context),
                        style: GoogleFonts.poppins(
                            color: ColorResources.COLOR_BLACK02,
                            fontWeight: FontWeight.w500,
                            fontSize: 14.0),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () async {
                      Navigator.pop(context, true);
                    },
                    child: Container(
                      color: Colors.white,
                      width: 100,
                      alignment: Alignment.center,
                      child: Text(
                        actionTitle ?? "",
                        style: GoogleFonts.poppins(
                            color: ColorResources.COLOR_BLACK,
                            fontWeight: FontWeight.w500,
                            fontSize: 14.0),
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  static Widget errorReload(String message, {Function callback}) {
    return Center(
        child: InkWell(
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: callback,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.refresh),
          Text(
            message ?? "",
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ));
  }

  static Widget stoppedAnimationProgress({color}) => CircularProgressIndicator(
        strokeWidth: 2.5,
        valueColor:
            AlwaysStoppedAnimation<Color>(color == null ? Colors.white : color),
      );

  static Widget redRadiusButton(String title, {Function onTap}) {
    return GestureDetector(
      // key: Key('login'),
      onTap: onTap,
      child: Container(
        height: 41,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(100)),
        child: Center(
          child: new Text(
            title,
            style: font13spW500.copyWith(color: Colors.white),
          ),
        ),
      ),
    );
  }

  static Widget dottedLinesWithSemiRounds(context, Color color,
          {Color dotColor}) =>
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Directionality.of(context) == TextDirection.rtl
              ? RotatedBox(
                  quarterTurns: 4,
                  child: Container(
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        bottomLeft: Radius.circular(15),
                      ),
                    ),
                    height: 25,
                    width: 13,
                  ),
                )
              : Container(
                  decoration: BoxDecoration(
                    // boxShadow: <BoxShadow>[
                    //   BoxShadow(
                    //       color: ColorResources.COLOR_GREY03,
                    //       blurRadius: 27,
                    //       spreadRadius: 0,
                    //       offset: Offset(0, 2))
                    // ],
                    color: color,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
                  ),
                  height: 25,
                  width: 13,
                ),
          Expanded(
              child: DottedLines(
            height: 1,
            color: dotColor ?? color,
          )),
          Directionality.of(context) == TextDirection.rtl
              ? RotatedBox(
                  quarterTurns: 2,
                  child: Container(
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        bottomLeft: Radius.circular(15),
                      ),
                    ),
                    height: 25,
                    width: 13,
                  ),
                )
              : Container(
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    ),
                  ),
                  height: 25,
                  width: 13,
                ),
        ],
      );
}

class DecimalTextInputFormatter extends TextInputFormatter {
  DecimalTextInputFormatter({this.decimalRange})
      : assert(decimalRange == null || decimalRange > 0);

  final int decimalRange;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue, // unused.
    TextEditingValue newValue,
  ) {
    TextSelection newSelection = newValue.selection;
    String truncated = newValue.text;

    if (decimalRange != null) {
      String value = newValue.text;

      if (value.contains(".") &&
          value.substring(value.indexOf(".") + 1).length > decimalRange) {
        truncated = oldValue.text;
        newSelection = oldValue.selection;
      } else if (value == ".") {
        truncated = "0.";

        newSelection = newValue.selection.copyWith(
          baseOffset: math.min(truncated.length, truncated.length + 1),
          extentOffset: math.min(truncated.length, truncated.length + 1),
        );
      }

      return TextEditingValue(
        text: truncated,
        selection: newSelection,
        composing: TextRange.empty,
      );
    }
    return newValue;
  }
}

class DecimalInput extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final regEx = RegExp(r"^\d*\.?\d*");
    String newString = regEx.stringMatch(newValue.text) ?? "";
    return newString == newValue.text ? newValue : oldValue;
  }
}

class ExpansionTileCustom extends ExpansionTile {
  bool expanded = false;

  final Widget titleWidget;
  final Widget content;

  ExpansionTileCustom({
    this.titleWidget,
    this.content,
  });

  changeValue() {
    expanded = !expanded;
  }

  @override
// TODO: implement expandedCrossAxisAlignment
  CrossAxisAlignment get expandedCrossAxisAlignment => CrossAxisAlignment.start;

  @override
// TODO: implement title
  Widget get title => titleWidget;

  @override
// TODO: implement children
  List<Widget> get children => [content];

  @override
  get onExpansionChanged => changeValue();

  @override
  // TODO: implement leading
  Widget get trailing => expanded
      ? Image.asset(Assets.icon('close_line.png'))
      : Image.asset(Assets.icon('plus.png'));

  @override
  // TODO: implement tilePadding
  EdgeInsetsGeometry get tilePadding => EdgeInsets.all(0);

  @override
  // TODO: implement childrenPadding
  EdgeInsetsGeometry get childrenPadding => EdgeInsets.only(bottom: 22);
}

class AppBarWithCustomHeight extends AppBar {
  final double height;
  final String titleName;
  final Widget bottomWidget;

  final List<Widget> action;

  AppBarWithCustomHeight({
    this.bottomWidget,
    this.height,
    this.titleName,
    this.action,
  });

  @override
  Widget get title => titleName == null
      ? super.title
      : Text(titleName,
          style: font19spW600.copyWith(color: ColorResources.COLOR_GREY03));

  @override
  bool get centerTitle => true;
  List<Widget> get actions => action;

  @override
  double get elevation => 0.0;

  @override
// TODO: implement bottom
  PreferredSizeWidget get bottom => bottomWidget ?? super.bottom;

  @override
  Size get preferredSize =>
      height == null ? super.preferredSize : Size.fromHeight(height);
}

class DottedLines extends StatelessWidget {
  final double height;
  final Color color;
  final double dashWidth;

  const DottedLines(
      {this.height = 1, this.color = Colors.black, this.dashWidth = 7.0});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final boxWidth = constraints.constrainWidth();
        // final dashWidth = 7.0;
        final dashHeight = height;
        final dashCount = (boxWidth / (2 * dashWidth)).floor();
        return Flex(
          children: List.generate(dashCount, (_) {
            return SizedBox(
              width: dashWidth,
              height: dashHeight,
              child: DecoratedBox(
                decoration: BoxDecoration(color: color),
              ),
            );
          }),
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          direction: Axis.horizontal,
        );
      },
    );
  }
}

class TextWithNA extends Text {
  TextWithNA(String data) : super(data ?? "Not available");
}
