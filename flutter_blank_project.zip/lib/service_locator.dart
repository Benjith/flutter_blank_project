// TODO Implement this library.import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'bloc/core_bloc.dart';
import 'bloc/language_bloc.dart';
import 'data/remote/dio/dio_client.dart';
import 'data/remote/dio/dio_interceptor.dart';

import 'helper/network_info.dart';

final sl = GetIt.instance;

Future<void> init() async {

  sl.registerLazySingleton(() => LanguageBloc());

}
